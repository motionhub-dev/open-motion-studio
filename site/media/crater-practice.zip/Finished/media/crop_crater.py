from pathlib import Path
import gzip
import hashlib
import json
import math
import struct

folder = Path(__file__).parent
tile = folder / "N46W123.hgt.gz"
packed = tile.read_bytes()
raw = gzip.decompress(packed)
side = math.isqrt(len(raw) // 2)
assert side * side * 2 == len(raw) and side == 3601
west, south, east, north = -122.225, 46.175, -122.145, 46.235
left, right = [round((lon + 123) * 3600) for lon in (west, east)]
top, bottom = [round((47 - lat) * 3600) for lat in (north, south)]
width = right - left + 1
grid = [list(struct.unpack_from(f">{width}h", raw, (row * side + left) * 2))
        for row in range(top, bottom + 1)]
assert all(-32768 not in row for row in grid)
metadata = dict(source="https://s3.amazonaws.com/elevation-tiles-prod/skadi/N46/N46W123.hgt.gz",
                attribution="Mapzen Terrain Tiles; https://github.com/tilezen/joerd/blob/master/docs/attribution.md",
                sha256=hashlib.sha256(packed).hexdigest(), units="metres",
                bounds_WGS84_sample_centres=[west, south, east, north], step_arcseconds=1,
                order="Rows north to south; columns west to east", width=width, height=len(grid),
                minimum=min(map(min, grid)), maximum=max(map(max, grid)))
(folder / "crater-heights.json").write_text(json.dumps(dict(**metadata, heights=grid)), encoding="utf-8")
section = grid[108]
print(metadata)
print("46.205 N, every .005 degree west to east:", section[::18])

from PIL import Image, ImageDraw

dx = 111320 * math.cos(math.radians(46.205)) / 3600
dy = 111132 / 3600
relief = Image.new("RGB", (width, len(grid)))
for row, values in enumerate(grid):
    for col, height in enumerate(values):
        slope_e = (values[min(width-1,col+1)] - values[max(0,col-1)]) / (2*dx)
        slope_n = (grid[max(0,row-1)][col] - grid[min(len(grid)-1,row+1)][col]) / (2*dy)
        light = (0.50*slope_e - 0.50*slope_n + 0.707) / math.sqrt(1+slope_e**2+slope_n**2)
        level = round(52+180*max(0, light))
        relief.putpixel((col,row), (level,level,level))
frame = Image.new("RGB",(580,700),"#141617")
draw = ImageDraw.Draw(frame)
map_height = round(500 * dy * (len(grid)-1) / (dx * (width-1)))
frame.paste(relief.resize((500, map_height)), (40, 62))
draw.text((40,18),"MOUNT ST. HELENS   /   SKADI ELEVATION STUDY",fill="white",font_size=19)
draw.text((40,42),"North up   |   NW hillshade   |   horizontal scale preserved",fill="silver",font_size=14)
draw.text((40,625),"Native samples: 289 x 217   /   1 arcsecond",fill="white",font_size=17)
draw.text((40,655),f"{metadata['minimum']} to {metadata['maximum']} m   /   Mapzen Terrain Tiles on AWS",fill="silver",font_size=15)
frame.save(folder / "crater-relief.png")
