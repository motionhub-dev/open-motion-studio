import {Film, Layer, Line, Scene, Sound, useTime} from '@motionhub/runtime';
import {Landscape} from './parts/Landscape';

/** The film's size and rate; its scenes decide its length. */
export const film = {width: 1280, height: 720, fps: 24};

function settle(time: number, start: number, end: number) {
  const phase = Math.max(0, Math.min(1, (time - start) / (end - start)));
  return phase * phase * (3 - 2 * phase);
}

function Flight() {
  const time = useTime();
  const wideRange = 6 * Math.pow(5000 / 6, settle(time, 2, 25));
  const closeRange = wideRange <= 8 ? wideRange : 8 + 2.5 * (1 - Math.exp(-(wideRange - 8) / 2.5));
  const distance = closeRange * Math.pow(wideRange / closeRange, settle(time, 13, 22));
  return <Landscape time={time} range={distance}
    angle={-0.24 + 0.46 * settle(time, 1, 15) - 0.18 * settle(time, 15, 26)}
    rise={1.52 + 0.16 * (distance - 6) + 0.16 * distance * settle(time, 15, 23)}
    focus={2.04 + 0.26 * Math.min(distance - 6, 16) + 125 * settle(time, 13, 25) * distance / wideRange}
    glint={0.58 * settle(time, 8, 15) * (1 - settle(time, 23, 26))}/>;
}

function WideTitle() {
  const time = useTime();
  const arrival = settle(time, 24.2, 26.3);
  return <div style={{opacity:arrival, transform:`translateY(${(1-arrival)*10}px)`, color:'#fff9e9', textShadow:'0 2px 14px #1a2329aa'}}>
    <div style={{font:'600 14px Arial, sans-serif', letterSpacing:3.7, marginBottom:12}}>MOUNT ST. HELENS   /   WASHINGTON</div>
    <div style={{font:'normal 70px Georgia, serif', letterSpacing:-3.8, lineHeight:1}}>The <i>Hollow</i> Mountain</div>
  </div>;
}

export default function Main() {
  return (
    <Film>
      <Sound src="media/original-score.wav" volume={-2} />
      <Scene id="northern-breach" duration={30}>
        <Line id="footfall" at={0} dur={8}>One pair of boots crosses the crater floor.</Line>
        <Line id="distance" at={8} dur={10}>The amber coat grows smaller. The walls keep rising.</Line>
        <Line id="breach" at={18} dur={7}>Through the northern breach, the sky fills the gap between the rims.</Line>
        <Line id="name" at={25} dur={5}>The Hollow Mountain. Mount St. Helens.</Line>
        <Layer id="landscape"><Flight /></Layer>
        <Layer id="wide-title" x={60} y={52} w={1160} h={170} z={2}><WideTitle /></Layer>
      </Scene>
    </Film>
  );
}
