import * as THREE from 'three';
import { useLayoutEffect, useRef } from 'react';
import relief from '../media/relief.json';

// Camera ranges and elevation are expressed in metres. North points along -Z.
export type Flight = { time:number; range:number; rise:number; angle:number; focus?:number; glint?:number };
const W=1280,H=720, a=relief.axis, n=a.length;
function cell(x:number){let l=0,r=n-1;while(r-l>1){let m=(r+l)>>1;if(a[m]<x)l=m;else r=m}return l}
function ground(x:number,z:number){
  const i=cell(x),j=cell(z),u=(x-a[i])/(a[i+1]-a[i]),v=(z-a[j])/(a[j+1]-a[j]);
  const h=relief.height,k=j*n+i;
  // Match the two triangles used to render this cell.
  return u+v<1?h[k]+u*(h[k+1]-h[k])+v*(h[k+n]-h[k]):h[k+n+1]+(1-u)*(h[k+n]-h[k+n+1])+(1-v)*(h[k+1]-h[k+n+1]);
}
function make(canvas:HTMLCanvasElement){
 const renderer=new THREE.WebGLRenderer({antialias:true,preserveDrawingBuffer:true,alpha:false,powerPreference:'high-performance'});
 renderer.setSize(W,H,false);renderer.setPixelRatio(1);
 const output=canvas.getContext('2d',{willReadFrequently:true})!;
 const pixels=new Uint8Array(W*H*4), frame=output.createImageData(W,H);
 const scene=new THREE.Scene(), cam=new THREE.PerspectiveCamera(46,W/H,.15,90000);
 scene.fog=new THREE.FogExp2(0x8f999d,.000077);
 const cache=atob(relief.pigment),rgb=new Uint8Array(relief.size**2*4);
 for(let i=0;i<rgb.length/4;i++){const c=cache.charCodeAt(2*i)|(cache.charCodeAt(2*i+1)<<8);rgb.set([Math.round(((c>>11)&31)*255/31),Math.round(((c>>5)&63)*255/63),Math.round((c&31)*255/31),255],i*4)}
 const tex=new THREE.DataTexture(rgb,relief.size,relief.size);tex.colorSpace=THREE.SRGBColorSpace;tex.magFilter=THREE.LinearFilter;tex.minFilter=THREE.LinearMipmapLinearFilter;tex.generateMipmaps=true;tex.needsUpdate=true;
 const pos=[],uv=[],indices=[];
 for(let j=0;j<n;j++){for(let i=0;i<n;i++){let k=j*n+i;pos.push(a[i],relief.height[k],a[j]);uv.push(i/(n-1),j/(n-1));if(i<n-1&&j<n-1)indices.push(k,k+n,k+1,k+1,k+n,k+n+1)}}
 const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));geo.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));geo.setIndex(indices);
 const earth=new THREE.MeshBasicMaterial({map:tex});
 earth.onBeforeCompile=s=>{
 s.vertexShader='varying vec3 surfacePoint;\n'+s.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nsurfacePoint=position;');
 s.fragmentShader='varying vec3 surfacePoint;\nfloat hashRock(vec2 p){return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453);}\nfloat noiseRock(vec2 p){vec2 i=floor(p),u=fract(p);u=u*u*(3.-2.*u);return mix(mix(hashRock(i),hashRock(i+vec2(1,0)),u.x),mix(hashRock(i+vec2(0,1)),hashRock(i+vec2(1)),u.x),u.y);}\n'+s.fragmentShader.replace('#include <map_fragment>','#include <map_fragment>\nvec2 p=surfacePoint.xz;float grit=noiseRock(p*8.)*.18+noiseRock(p*2.6)*.20+noiseRock(p*.44)*.21;float seam=abs(sin(surfacePoint.y*.71+noiseRock(p*.052)*2.9+p.x*.1));float gravel=smoothstep(.42,.80,noiseRock(p*4.3));diffuseColor.rgb=diffuseColor.rgb*(.66+grit+.16*seam)+vec3(.023,.017,.012)*gravel;')
 };
 scene.add(new THREE.Mesh(geo,earth));
 const sky=new THREE.Mesh(new THREE.SphereGeometry(55000,44,26),new THREE.ShaderMaterial({side:THREE.BackSide,depthWrite:false,uniforms:{clock:{value:0}},
 vertexShader:'varying vec3 v; void main(){v=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
 fragmentShader:`varying vec3 v;uniform float clock;
 float h(vec2 p){return fract(sin(dot(p,vec2(41.1,239.7)))*43758.54);}
 float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(h(i),h(i+vec2(1,0)),f.x),mix(h(i+vec2(0,1)),h(i+1.),f.x),f.y);}
 void main(){vec3 d=normalize(v);float y=max(0.,d.y);float glow=pow(max(0.,dot(d,normalize(vec3(-.76,.12,.62)))),6.);
 vec3 col=mix(vec3(.63,.66,.68),vec3(.16,.23,.32),smoothstep(.0,.74,y));col+=vec3(.32,.11,-.04)*glow;
 vec2 q=d.xz/max(.065,y+.08)*vec2(1.1,1.9)+vec2(clock*.003,0);float clouds=noise(q*.8)*.55+noise(q*2.1)*.29+noise(q*5.1)*.16;
 col+=vec3(.14,.12,.10)*(clouds-.48)*smoothstep(0.,.12,y);
 gl_FragColor=vec4(col,1.);}`}));
 sky.renderOrder=-10;scene.add(sky);
 const sun=new THREE.DirectionalLight(0xffdb9f,2.7);sun.position.set(-90,80,50);scene.add(sun,new THREE.HemisphereLight(0xe3f2ff,0x54483b,1.8));
 const walker=new THREE.Group();scene.add(walker);
 function piece(g:THREE.BufferGeometry,c:number,p:number[],parent=walker){const m=new THREE.Mesh(g,new THREE.MeshStandardMaterial({color:c,roughness:.95}));m.position.set(p[0],p[1],p[2]);parent.add(m);return m}
 function oval(scale:number[],color:number,where:number[],parent=walker){const m=piece(new THREE.SphereGeometry(1,18,14),color,where,parent);m.scale.set(scale[0],scale[1],scale[2]);return m}
 const ochre=0xc76021, glove=0x42352e, bootLeather=0x352c24;
 const coat=oval([.235,.348,.165],ochre,[0,1.16,0]);coat.rotation.x=.095;
 oval([.213,.115,.15],0xb04e1d,[0,.955,0]);
 oval([.137,.159,.123],0xb6855f,[0,1.61,.037]);
 oval([.156,.173,.15],0xdd7d28,[0,1.656,-.015]);
 oval([.132,.108,.067],0x8b664d,[0,1.598,.107]);
 oval([.195,.276,.126],0x4b4940,[0,1.23,-.166]);
 oval([.18,.089,.11],0x585544,[0,1.45,-.183]);
 oval([.132,.104,.061],0x6e6651,[0,1.19,-.26]);
 for(let side of [-1,1]){let strap=oval([.037,.209,.053],0x403d30,[side*.147,1.29,.092]);strap.rotation.z=-side*.14}
 const limbs=[-1,1].map(side=>{const p=new THREE.Group();p.position.set(.101*side,.92,0);walker.add(p);
 let thigh=oval([.094,.263,.087],0x43403a,[0,-.203,0],p);thigh.rotation.x=.12;
 let calf=oval([.073,.217,.066],0x373936,[0,-.606,-.039],p);calf.rotation.x=-.13;
 oval([.087,.088,.147],bootLeather,[0,-.839,.011],p);
 const arm=new THREE.Group();arm.position.set(side*.204,1.40,.01);walker.add(arm);
 let upper=oval([.077,.174,.077],ochre,[side*.028,-.106,0],arm);upper.rotation.z=side*.14;
 let lower=oval([.063,.136,.062],0xad541e,[side*.064,-.323,.044],arm);lower.rotation.x=-.38;
 oval([.055,.065,.053],glove,[side*.061,-.444,.092],arm);
 return {p,arm,side}});
 // Foreground basalt gives the opening scale before the camera sees the whole basin.
 let seed=742;const rand=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/4294967296);
 const rocks=new THREE.InstancedMesh(new THREE.DodecahedronGeometry(1,0),new THREE.MeshStandardMaterial({color:0x514b44,roughness:1}),2200);
 const obj=new THREE.Object3D(); for(let i=0;i<rocks.count;i++){let x=116+(rand()-.5)*(i<1450?32:140),z=-798+(rand()-.5)*(i<1450?32:140),r=.022+Math.pow(rand(),5)*(i<1450?.24:.88);obj.position.set(x,ground(x,z)-r*.19,z);obj.rotation.set(rand(),rand()*6,rand());obj.scale.set(r,r*.52,r*.78);obj.updateMatrix();rocks.setMatrixAt(i,obj.matrix)}scene.add(rocks);
 // The boot shadow and wind-blown grit ground the foreground figure on the survey surface.
 const shadeCanvas=document.createElement('canvas');shadeCanvas.width=shadeCanvas.height=128;
 const brush=shadeCanvas.getContext('2d')!,grad=brush.createRadialGradient(64,64,0,64,64,64);
 grad.addColorStop(0,'rgba(20,15,12,.72)');grad.addColorStop(.40,'rgba(20,15,12,.48)');grad.addColorStop(1,'rgba(20,15,12,0)');
 brush.fillStyle=grad;brush.fillRect(0,0,128,128);
 const shadowTexture=new THREE.CanvasTexture(shadeCanvas);
 const shadow=new THREE.Mesh(new THREE.PlaneGeometry(1.4,2.8),new THREE.MeshBasicMaterial({map:shadowTexture,transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2}));
 shadow.rotation.x=-Math.PI/2;scene.add(shadow);
 const veil=new THREE.Group();scene.add(veil);
 const fogCanvas=document.createElement('canvas');fogCanvas.width=256;fogCanvas.height=64;const ink=fogCanvas.getContext('2d')!;
 for(let i=0;i<65;i++){let x=rand()*220+18,y=25+rand()*14,r=5+rand()*16;let g=ink.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,'rgba(197,204,202,.12)');g.addColorStop(1,'rgba(197,204,202,0)');ink.fillStyle=g;ink.fillRect(x-r,y-r,r*2,r*2)}
 const fogTex=new THREE.CanvasTexture(fogCanvas);
 for(let i=0;i<21;i++){let sx=(rand()-.5)*8500,sz=(rand()-.5)*8200;let layer=new THREE.Sprite(new THREE.SpriteMaterial({map:fogTex,opacity:.16+rand()*.14,transparent:true,depthWrite:false,fog:true}));
 layer.position.set(sx,ground(sx,sz)+45+rand()*135,sz);layer.scale.set(1500+rand()*1800,75+rand()*140,1);veil.add(layer)}
 const screen=new THREE.Vector3();
 function draw(f:Flight){
 const t=f.time,x=116+Math.min(t,18)*.31,z=-798+Math.min(t,18)*.12,y=ground(x,z);
 shadow.position.set(x+.18,y+.078,z+.39);shadow.rotation.z=-.32;
 veil.position.x=t*1.6;
 walker.position.set(x,y+.035*Math.sin(t*6),z);walker.rotation.y=1.13;
 for(const {p,arm,side} of limbs){let pace=Math.sin(t*4.5)*side*(1-THREE.MathUtils.smoothstep(t,17,19));p.rotation.x=pace*.42;arm.rotation.x=-pace*.40}
 const a=f.angle,r=f.range,cx=x+r*Math.sin(a),cz=z-r*Math.cos(a);
 cam.position.set(cx,Math.max(ground(cx,cz)+1.35,y+f.rise),cz);
 cam.lookAt(x,y+(f.focus??1),z);cam.updateMatrixWorld();
 sky.position.copy(cam.position);sky.material.uniforms.clock.value=t;
 renderer.render(scene,cam);
 const context=renderer.getContext();
 context.readPixels(0,0,W,H,context.RGBA,context.UNSIGNED_BYTE,pixels);
 for(let row=0;row<H;row++){
   const start=(H-1-row)*W*4;
   frame.data.set(pixels.subarray(start,start+W*4),row*W*4);
 }
 output.putImageData(frame,0,0);
 // Light caught on the coat can be art-directed independently of camera timing.
 if(f.glint){screen.set(x,y+1.2,z).project(cam);let sx=(screen.x+1)*W/2,sy=(1-screen.y)*H/2,rad=6;let grd=output.createRadialGradient(sx,sy,.4,sx,sy,rad);grd.addColorStop(0,'rgba(255,190,106,'+f.glint+')');grd.addColorStop(1,'rgba(255,150,55,0)');output.fillStyle=grd;output.fillRect(sx-rad,sy-rad,rad*2,rad*2)}
 }
 return {draw,dispose(){scene.traverse(o=>{if(o instanceof THREE.Mesh){o.geometry.dispose();for(const m of [].concat(o.material as any))m.dispose()}});tex.dispose();shadowTexture.dispose();fogTex.dispose();renderer.dispose();renderer.forceContextLoss()}};
}
export function Landscape(props:Flight){
 const canvas=useRef<HTMLCanvasElement>(null),rig=useRef<ReturnType<typeof make>|null>(null);
 useLayoutEffect(()=>{rig.current=make(canvas.current!);return ()=>{rig.current?.dispose();rig.current=null}},[]);
 useLayoutEffect(()=>{rig.current?.draw(props)},[props.time,props.range,props.rise,props.angle,props.focus,props.glint]);
 return <canvas ref={canvas} width={W} height={H} style={{display:'block',width:'100%',height:'100%'}}/>;
}
