import {Film, Layer, Line, Scene, Sound, useTime} from '@motionhub/runtime';
import {Landscape} from './parts/Landscape';

/** The film's size and rate; its scenes decide its length. */
export const film = {width: 1280, height: 720, fps: 24};

function settle(time: number, start: number, end: number) {
  const phase = Math.max(0, Math.min(1, (time - start) / (end - start)));
  return phase * phase * (3 - 2 * phase);
}

function Flight() {
  const time = useTime();
  const distance = 6 * Math.pow(5000 / 6, settle(time, 2, 25));
  return <Landscape time={time} range={distance}
    angle={-1.13 * (1 - settle(time, 2, 13))}
    rise={2.3 + 0.27 * (distance - 6)}
    focus={1.05 + 130 * settle(time, 13, 25)}
    glint={0.58 * settle(time, 8, 15) * (1 - settle(time, 23, 26))}/>;
}

function WideTitle() {
  const time = useTime();
  return <div style={{opacity: settle(time, 25, 26.6), color: '#fff8e8',
    textShadow: '0 2px 12px #151b20', fontFamily: 'Georgia, serif'}}>
    <div style={{fontSize: 88, letterSpacing: '-0.045em', lineHeight: 1.05}}>The Hollow Mountain</div>
    <div style={{fontSize: 40, lineHeight: 1.25, marginTop: 8, opacity: settle(time, 26, 27.4)}}>Mount St. Helens</div>
  </div>;
}

export default function Main() {
  return (
    <Film>
      <Sound src="media/original-score.wav" volume={-14} />
      <Scene id="northern-breach" duration={30}>
        <Line id="footfall" at={0} dur={8}>One pair of boots crosses the crater floor.</Line>
        <Line id="distance" at={8} dur={10}>The amber coat grows smaller. The walls keep rising.</Line>
        <Line id="breach" at={18} dur={7}>Through the northern breach, the sky fills the gap between the rims.</Line>
        <Line id="name" at={25} dur={5}>The Hollow Mountain. Mount St. Helens.</Line>
        <Layer id="landscape"><Flight /></Layer>
        <Layer id="wide-title" x={60} y={52} w={1160} h={170} z={2}><WideTitle /></Layer>
      </Scene>
    </Film>
  );
}
